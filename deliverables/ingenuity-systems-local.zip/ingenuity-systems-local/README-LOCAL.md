# Ingenuity Systems — local website package

## Run it
Requirements: Python 3.10 or newer. No pip packages are required.
- macOS/Linux: `python3 server.py`
- Windows: `py server.py`
Then open http://127.0.0.1:5000. Stop with Ctrl+C. Set `PORT` before starting if 5000 is occupied.

## Optional integrations
The website runs without Replit. Replit secrets are intentionally not included in this ZIP.
The assistant needs `OPENAI_API_KEY`. Contact-form delivery is handled by external Make scenarios
and an intake app; the site does not send email directly. For local contact submissions, configure
these environment variables in your terminal before starting:
- Primary Make router: `INGENUITY_ROUTER_WEBHOOK_URL` or `MAKE_WEBHOOK_URL`
- Second Make form webhook: `MAKE_SECOND_WEBHOOK_URL`
- Intake app endpoint: `APP_INTAKE_WEBHOOK_URL` (must be HTTPS)
- Optional assistant model: `OPENAI_CHAT_MODEL` (defaults to `gpt-4o-mini`)
- Optional Calendly webhook verification: `CALENDLY_WEBHOOK_SIGNING_KEY`

The actual confirmation and follow-up emails depend on the downstream Make scenarios being active.
A successful website submission only confirms webhook acceptance; it does not prove inbox delivery.

## Safe local check
Run `python3 tests/check_routes.py` to check routes, local assets, compression, and cache headers.
It does not submit the contact form, call external APIs, or send emails.
