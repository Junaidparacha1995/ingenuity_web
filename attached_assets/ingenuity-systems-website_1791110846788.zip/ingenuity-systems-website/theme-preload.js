// The site is light-only. Clear any theme saved by older versions so nothing
// (including a dark OS setting) can switch the site into a dark theme.
(function () {
  document.documentElement.dataset.theme = 'light';
  document.documentElement.style.colorScheme = 'light';
  try { window.localStorage.removeItem('ingenuity-theme'); } catch (error) {}
})();
